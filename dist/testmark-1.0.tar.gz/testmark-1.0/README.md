# testmark 

is a testmark -> markup parser. 

it parses markup for specific codeblocks beginning with a comment.
The string inside of this markup then can be used for documentation in your markup but aswell be used in testing software or other stuff.


inspired by [go-testmark](https://github.com/warpfork/go-testmark) where it is also **specification**.

