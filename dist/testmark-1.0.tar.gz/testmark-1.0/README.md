# python testmark parser

inspired by https://github.com/warpfork/go-testmark

issues and improvement suggestions very welcome. 

in development - missing: 1. making a package out of it 2. some more infos on usage 3. license
